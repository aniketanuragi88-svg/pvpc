package com.example.pvpclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.nio.file.*;

/** Settings. Edit config/pvpclient/config.json. Corrupt files are backed up and reset. */
public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public boolean showFps = true;
    public boolean showCps = true;
    public boolean showCoords = true;
    public boolean showKeystrokes = true;
    public int x = 4;          // HUD left position
    public int y = 4;          // HUD top position
    public float scale = 1.0f; // 0.5 - 2.0 (small screens: try 0.8)
    public int textColor = 0xFF55FFFF; // ARGB, cyan
    public int bgColor = 0x80000000;   // ARGB, translucent black

    public void clamp() {
        if (scale < 0.5f || scale > 2.0f || Float.isNaN(scale)) scale = 1.0f;
        if (x < 0) x = 0;
        if (y < 0) y = 0;
    }

    public static Config load(Path file) {
        try {
            if (Files.exists(file)) {
                Config c = GSON.fromJson(Files.readString(file), Config.class);
                if (c != null) { c.clamp(); return c; }
            }
        } catch (Exception e) {
            PvpClient.LOG.error("Config corrupt, backing up and resetting", e);
            try {
                Files.move(file, file.resolveSibling("config.json.corrupt-" + System.currentTimeMillis()),
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (Exception ignored) {}
        }
        Config fresh = new Config();
        fresh.save(file);
        return fresh;
    }

    public void save(Path file) {
        try {
            Files.createDirectories(file.getParent());
            Path tmp = file.resolveSibling("config.json.tmp");
            Files.writeString(tmp, GSON.toJson(this));
            try {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            PvpClient.LOG.error("Config save failed", e);
        }
    }
}
