package com.example.pvpclient;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class Hud {
    private static long fpsWindowStart = System.currentTimeMillis();
    private static int frames, fps;

    private Hud() {}

    public static void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(PvpClient.ID, "hud"),
                Hud::render);
    }

    private static void render(GuiGraphics g, DeltaTracker delta) {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.options.hideGui) return;
            Config c = PvpClient.config;

            // own FPS counter (no dependency on internal getters)
            frames++;
            long now = System.currentTimeMillis();
            if (now - fpsWindowStart >= 1000) {
                fps = frames;
                frames = 0;
                fpsWindowStart = now;
            }

            var pose = g.pose();
            pose.pushMatrix();
            pose.translate(c.x, c.y);
            pose.scale(c.scale, c.scale);

            int line = 0;
            if (c.showFps) text(g, mc, "FPS: " + fps, 0, line++ * 11, c);
            if (c.showCps) text(g, mc, "CPS: " + Cps.left() + " | " + Cps.right(), 0, line++ * 11, c);
            if (c.showCoords) {
                text(g, mc, String.format("XYZ: %.1f %.1f %.1f",
                        mc.player.getX(), mc.player.getY(), mc.player.getZ()), 0, line++ * 11, c);
            }
            if (c.showKeystrokes) {
                int top = line * 11 + 4;
                key(g, mc, mc.options.keyUp, "W", 24, top, c);
                key(g, mc, mc.options.keyLeft, "A", 0, top + 24, c);
                key(g, mc, mc.options.keyDown, "S", 24, top + 24, c);
                key(g, mc, mc.options.keyRight, "D", 48, top + 24, c);
            }
            pose.popMatrix();
        } catch (Throwable t) {
            // Never crash the game from the HUD: disable it and log once.
            PvpClient.LOG.error("HUD render failed, disabling HUD", t);
            PvpClient.config.showFps = false;
            PvpClient.config.showCps = false;
            PvpClient.config.showCoords = false;
            PvpClient.config.showKeystrokes = false;
        }
    }

    private static void text(GuiGraphics g, Minecraft mc, String s, int x, int y, Config c) {
        int w = mc.font.width(s);
        g.fill(x - 2, y - 1, x + w + 2, y + 9, c.bgColor);
        g.drawString(mc.font, s, x, y, c.textColor);
    }

    private static void key(GuiGraphics g, Minecraft mc, KeyMapping k, String label, int x, int y, Config c) {
        boolean down = k.isDown();
        g.fill(x, y, x + 22, y + 22, down ? 0xA0FFFFFF : c.bgColor);
        g.drawString(mc.font, label, x + 11 - mc.font.width(label) / 2, y + 7,
                down ? 0xFF000000 : c.textColor);
    }
}
