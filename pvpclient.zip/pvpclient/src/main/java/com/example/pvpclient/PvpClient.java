package com.example.pvpclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.*;

public class PvpClient implements ClientModInitializer {
    public static final String ID = "pvpclient";
    public static final Logger LOG = LoggerFactory.getLogger(ID);

    public static Config config = new Config();
    public static boolean safeMode = false;

    @Override
    public void onInitializeClient() {
        try {
            Path dir = FabricLoader.getInstance().getConfigDir().resolve(ID);
            Files.createDirectories(dir);

            // Safe mode: manual flag file, or the last launch never finished starting.
            Path flag = dir.resolve("safemode.flag");
            Path lock = dir.resolve("launching.lock");
            if (Files.exists(flag) || Files.exists(lock)) {
                safeMode = true;
                LOG.warn("PvP Client SAFE MODE active (HUD disabled).");
            }
            Files.writeString(lock, "started");
            ClientLifecycleEvents.CLIENT_STARTED.register(c -> {
                try { Files.deleteIfExists(lock); } catch (Exception ignored) {}
            });

            config = Config.load(dir.resolve("config.json"));

            if (!safeMode) {
                ClientTickEvents.END_CLIENT_TICK.register(Cps::tick);
                Hud.register();
            }
            LOG.info("PvP Client loaded (safeMode={})", safeMode);
        } catch (Throwable t) {
            safeMode = true;
            LOG.error("PvP Client failed to initialise, running disabled", t);
        }
    }
}
