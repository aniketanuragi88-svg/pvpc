# PvP Client (v0.1) - Fabric 1.21.11

Includes: FPS, CPS, coordinates, keystrokes HUD. Config recovery. Safe mode. No mixins.

## Get the JAR (phone only)
1. Make a free account at github.com and create a new repository.
2. Upload ALL files from this zip (keep the folder structure, including `.github/workflows/build.yml`).
3. Open the repo -> **Actions** tab -> wait for "Build" to finish (green tick).
4. Open the finished run -> **Artifacts** -> download `pvpclient-jar` (a zip containing the .jar).
5. If the build is red: open it, copy the error text, and send it to Claude.

## Install on MJLauncher
1. Install Fabric Loader for 1.21.11.
2. Put `fabric-api-*.jar` (from modrinth.com, 1.21.11) and `pvpclient-0.1.0.jar` in the `mods` folder.
3. Launch.

## Configure
Edit `config/pvpclient/config.json` (turn items on/off, change `x`, `y`, `scale`). A touch menu is planned for the next version.

## Safe mode
- Create an empty file `config/pvpclient/safemode.flag` to disable the HUD.
- It also turns on automatically if the previous launch never finished loading.

## Crash logs
Send `logs/latest.log` and the newest file in `crash-reports/`.

## Honest notes
Not compiled or tested by the author. Version numbers in `gradle.properties` may need updating, and some 1.21.11 class names may need small fixes. Send build errors back and they get fixed.
